import {
  createGesture
} from "./chunk-LRRXMVX2.js";
import {
  GESTURE_CONTROLLER
} from "./chunk-OWX7YSRF.js";
import "./chunk-ZVATTXSA.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
