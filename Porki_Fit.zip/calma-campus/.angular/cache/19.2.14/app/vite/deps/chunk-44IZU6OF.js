// node_modules/@ionic/core/components/index9.js
var win = typeof window !== "undefined" ? window : void 0;
var doc = typeof document !== "undefined" ? document : void 0;

export {
  win,
  doc
};
/*! Bundled license information:

@ionic/core/components/index9.js:
  (*!
   * (C) Ionic http://ionicframework.com - MIT License
   *)
*/
//# sourceMappingURL=chunk-44IZU6OF.js.map
